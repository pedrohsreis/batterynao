#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "iostream"
#include "QProcess"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)


{
    ui->setupUi(this);

   /* //ui->btnStatusBateria->show();
    //ui->selectNaoBox->show();
    QString programa = "/home/pedro/Desktop/naoqi-sdk-2.1.4.13-linux64/naobattery/build-mytoolchain/sdk/bin/naobattery nao03.local";
    QProcess* process = new QProcess(this);
    if(/*ui->btnStatusBateria->clicked() 1 == 1){
        if(/*ui->selectNaoBox->currentText() == "NAO03" 1 == 1){
            process->start(programa, QStringList() << "");
        }
    }*/
}

MainWindow::~MainWindow()
{
    delete ui;
}
