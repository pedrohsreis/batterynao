#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "iostream"
#include "QProcess"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)


{
    ui->setupUi(this);

    QObject* button = QObject::sender();

    QString programa = "/build-mytoolchain/sdk/bin/naobattery nao03.local";
    QProcess* process = new QProcess(this);
    if(button = ui->btnStatusBateria){
        if(ui->selectNaoBox->currentText() == "NAO03"){
            process->start(programa, QStringList() << "");
        }
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}
